"""
Domain-justified cost matrices for each dataset.

Each entry defines:
  - cost_fn: cost of a False Negative (missing the positive/minority class)
  - cost_fp: cost of a False Positive (false alarm)
  - cost_tp, cost_tn: typically 0 (no cost for correct predictions) unless
    noted otherwise
  - source / justification: where the ratio comes from

IMPORTANT: these are illustrative, literature-grounded ratios, not
measured values specific to these exact datasets (which is true of every
cost-sensitive-learning paper using public benchmark data -- this
limitation must be stated explicitly in the paper's Methodology and
Limitations sections). A cost-ratio sensitivity ablation (varying the
ratio across a plausible range) is run separately to show findings are
not an artifact of one specific ratio choice.
"""

COST_MATRICES = {
    "ai4i2020": {
        "cost_fn": 99,   # missed machine failure -> reactive repair cost
        "cost_fp": 55,   # false alarm -> unnecessary maintenance dispatch
        "cost_tp": 0,
        "cost_tn": 0,
        "ratio_fn_fp": 99 / 55,  # ~1.8
        "source": (
            "Cost figures adapted from Spiegel, Mueller, Wiesmann and "
            "Bird, 'Cost-Sensitive Learning for Predictive Maintenance' "
            "(arXiv:1809.10979, Fig. 4): a reactive-failure cost of $99 "
            "($32 ticket + $51 service + $16 downtime) and a false-alarm "
            "cost of $55 (unnecessary service visit). The source calls "
            "these costs realistic but artificial and also charges $55 "
            "for a true positive; here correct predictions cost zero, "
            "as for every other dataset. Used as a representative ratio "
            "for industrial predictive maintenance, not a cost specific "
            "to the AI4I 2020 dataset itself."
        ),
        "sensitivity_range": [1.0, 1.8, 3.0, 5.0, 10.0],  # FN:FP ratios to test
    },
    "pima_diabetes": {
        "cost_fn": 5,    # missed diabetes diagnosis -> delayed treatment
        "cost_fp": 1,    # unnecessary follow-up testing
        "cost_tp": 0,
        "cost_tn": 0,
        "ratio_fn_fp": 5.0,
        "source": (
            "UNVERIFIED illustrative ratio (5:1), chosen to reflect the "
            "general clinical principle that a missed diagnosis (delayed "
            "treatment, disease progression) is costlier than an "
            "unnecessary follow-up test. Unlike the AI4I and German "
            "Credit ratios, this one is NOT drawn from a specific cited "
            "source -- a literature search for a documented FN:FP cost "
            "ratio specific to diabetes screening should be done before "
            "finalizing the paper, and this must be stated as a weaker-"
            "justified ratio relative to the other two datasets."
        ),
        "sensitivity_range": [1.0, 3.0, 5.0, 8.0, 10.0],
    },
    "german_credit": {
        # German Credit has a well-known, literature-standard cost matrix
        # (Statlog convention): classifying a BAD customer as GOOD costs
        # 5x more than classifying a GOOD customer as BAD.
        "cost_fn": 5,    # bad credit risk predicted as good -> loan default
        "cost_fp": 1,    # good credit risk predicted as bad -> lost business
        "cost_tp": 0,
        "cost_tn": 0,
        "ratio_fn_fp": 5.0,
        "source": (
            "Official cost matrix specified by the UCI Statlog German "
            "Credit Data documentation itself (archive.ics.uci.edu/"
            "dataset/144): classifying a bad credit risk as good costs "
            "5, classifying a good credit risk as bad costs 1. This is "
            "the dataset's own required cost matrix, not an external or "
            "assumed convention -- the strongest-justified cost matrix "
            "among the four datasets used in this study."
        ),
        "sensitivity_range": [1.0, 3.0, 5.0, 7.0, 10.0],
    },
    "adult_income": {
        # General-purpose dataset; no natural domain cost. Used as a
        # comparison point with a moderate illustrative ratio.
        "cost_fn": 2,
        "cost_fp": 1,
        "cost_tp": 0,
        "cost_tn": 0,
        "ratio_fn_fp": 2.0,
        "source": (
            "No established domain cost convention exists for this "
            "general-purpose dataset. A moderate illustrative ratio "
            "(2:1) is used, intentionally lower than the domain-specific "
            "ratios, to serve as a contrast point in the imbalance-"
            "severity analysis. This is clearly weaker justification "
            "than the other three datasets and is stated as such."
        ),
        "sensitivity_range": [1.0, 2.0, 3.0, 5.0],
    },

    # ------------------------------------------------------------------
    # Extension datasets. NONE of these has an official or sourced cost
    # matrix; every ratio below is an ILLUSTRATIVE domain-reasoned choice
    # and is stated as such in the paper. The cost-ratio sensitivity
    # analysis (wide grid) is what carries the conclusions.
    # ------------------------------------------------------------------
    "spambase": {
        # positive = spam. A legitimate e-mail filtered as spam (FP) is
        # usually considered worse than spam reaching the inbox (FN).
        "cost_fn": 1, "cost_fp": 10, "cost_tp": 0, "cost_tn": 0,
        "ratio_fn_fp": 0.1,
        "source": "ILLUSTRATIVE: FP (legitimate mail lost) assumed 10x costlier than FN (spam delivered). Not sourced; covered by sensitivity grid 0.05-1.",
        "sensitivity_range": [0.05, 0.1, 0.2, 0.5, 1.0],
    },
    "wdbc": {
        # positive = malignant. Missing a cancer is costlier than a false alarm.
        "cost_fn": 5, "cost_fp": 1, "cost_tp": 0, "cost_tn": 0,
        "ratio_fn_fp": 5.0,
        "source": "ILLUSTRATIVE: missed malignancy (FN) assumed 5x costlier than a false alarm leading to extra tests (FP). Not sourced; sensitivity grid 1-20.",
        "sensitivity_range": [1.0, 3.0, 5.0, 10.0, 20.0],
    },
    "coil2000": {
        # positive = customer buys the insurance product (6% of customers).
        "cost_fn": 10, "cost_fp": 1, "cost_tp": 0, "cost_tn": 0,
        "ratio_fn_fp": 10.0,
        "source": "ILLUSTRATIVE: a missed buyer (FN) assumed 10x costlier than a wasted mailing (FP), reflecting the rarity (6%) of buyers. Not sourced; sensitivity grid 2-20.",
        "sensitivity_range": [2.0, 5.0, 10.0, 20.0],
    },
}

if __name__ == "__main__":
    for name, cm in COST_MATRICES.items():
        print(f"{name}: FN=${cm['cost_fn']}, FP=${cm['cost_fp']}, "
              f"ratio={cm['ratio_fn_fp']:.2f}")
